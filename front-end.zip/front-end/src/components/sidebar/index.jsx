import React from 'react'
import './style.css'

const Sidebar = () => {
  return <div>sidebar</div>
};

export default Sidebar