import React from 'react'

const Header = () => {
  return <div>header</div>
};

export default Header