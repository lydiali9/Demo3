import React from 'react'
import { Provider, connect } from 'react-redux'
import { Router, Route, Switch, Redirect } from 'react-router-dom';
import { isLogin } from '../common/utils'
import store from '../redux/store.js'
import history from '../redux/history.js'
import Login from '../page/main/login.jsx'
import Register from '../page/main/register.jsx'
import Setting from '../page/main/setting.jsx'
import Home from '../page/home/index.jsx'
import App from '../page/app.jsx'
import Express from '../page/express/index.jsx'
import Activity from '../page/activity/index.jsx'
import Offline from '../page/offline/index.jsx'
import Violation from '../page/violation/index.jsx'

class AuthRequiredRoute extends Route {
  render() {
    if (!isLogin()) {
      return <Redirect to="/login"></Redirect>
    } else {
      return <Route path={this.props.path} component={this.props.component} />
    }
  }
}

const Root = () => {
  return (
    <Provider store={store}>
      <Router history={history}>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/setting" component={Setting} />
          <Route path="/express" component={Express} />
          <Route path="/activity" component={Activity} />
          <Route path="/offline" component={Offline} />
          <AuthRequiredRoute path="/violation" component={Violation} />
        </Switch>
      </Router>
    </Provider>
  )
};

export default Root;

