'use strict';

module.exports = {
    PRODUCT_SDK_ID: "wwf20180609",
    PRODUCT_SDK_SECRET: "6be4cb0d087e2d62b4173c01798ab1b87bf4f3ba",
    PRODUCT_SDK_KEY: "7fe373c77cf67e185bf5a3d0af906e79",
    TOKEN_SECRET: 'supersecret', // used when we create and verify JSON Web Tokens
    CMS_VERSION: "1.0",
    APP_ID: "wx90e38c25fda979a0",
    MCH_ID: "1510327711",
    PACKAGE: "Sign=WXPay",
    NOT_PAY: 0,
    PAY_COMPLETE: 1
}