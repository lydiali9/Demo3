const https = "https://";
const http = "http://";
//TOFIX
let wxpaynotify_url = "http://218.17.116.242:49825/api/order/wxpaynotify"
if(process.env.NODE_ENV == 'development'){
    wxpaynotify_url = "http://218.17.116.242:49826/api/order/wxpaynotify"
} else if(process.env.NODE_ENV == 'production'){
    wxpaynotify_url = "http://218.17.116.242:49825/api/order/wxpaynotify"
}else if(process.env.NODE_ENV=='test'){
    wxpaynotify_url = 'http://106.75.49.177:8081/api/order/wxpaynotify';
}
module.exports = {
    // expressage
    get_expressage: https + 'sp0.baidu.com/9_Q4sjW91Qh3otqbppnN2DJv/pae/channel/data/asyncqury',

    // activity
    query_activity: http + 'openapi.huodongxing.com/v1/act/flist',
    get_activity: http + 'openapi.huodongxing.com/v1/act/detail',

    // vehicle
    get_vehicle_violation: https + 'mys4s.cn/v3/violation/web/query',
    get_violation_html: https + 'mys4s.cn/static/vio/index.html#/',

    // code
    get_code: 'https://iaccount.inveno.com/user/get_code',
    register: 'https://iaccount.inveno.com/user/register',
    wechat_pay: 'https://api.mch.weixin.qq.com/pay/unifiedorder',
    wechat_order_query: "https://api.mch.weixin.qq.com/pay/orderquery",
    //开发环境
    wxpaynotify_url,
    //测试环境
    alipaynotify_url: "http://111.230.164.70:1449/alipaynotify/",
};