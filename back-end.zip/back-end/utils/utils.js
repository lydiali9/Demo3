/**
 * Common
 * Created by yuhua.li
 */
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');

let md5 = require('md5');
const CONFIG = require("./constant");


function S4() {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}

const utils = {
    createUid: function () {
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
    },

    createToken: function (phone_num, timestamp) {
        return md5(CONFIG.PRODUCT_SDK_SECRET + ":" + phone_num + ":" + timestamp);
    },

    generateToken: function (userId) {
        let token = jwt.sign({ id: userId }, CONFIG.TOKEN_SECRET, {
            expiresIn: 365 * 24 * 60 * 60 * 1000// expires in one year
        });

        return token;
    },
    uuid: function (len, radix) {
        let chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split(''),
            uuid = [],
            i;
        radix = radix || chars.length;

        if (len) {
            for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
        } else {
            let r;
            uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
            uuid[14] = '4';
            for (i = 0; i < 36; i++) {
                if (!uuid[i]) {
                    r = 0 | Math.random() * 16;
                    uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
                }
            }
        }
        return uuid.join('');
    },
    formatDate: function (date, fmt = "yyyy-MM-dd") {
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
        }
        let o = {
            'M+': date.getMonth() + 1,
            'd+': date.getDate(),
            'h+': date.getHours(),
            'm+': date.getMinutes(),
            's+': date.getSeconds()
        };
        for (let k in o) {
            if (new RegExp(`(${k})`).test(fmt)) {
                let str = o[k] + '';
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : ('00' + str).substr(str.length));
            }
        }
        return fmt;
    },
    isEmpty: function (v) {
        switch (typeof v) {
            case 'undefined':
                return true;
            case 'string':
                if (v.replace(/^\s+|\s+$/g, "").length === 0) {
                    return true;
                }
                return false;
            case 'boolean':
                return v;
            case 'number':
                if (isNaN(v)) {
                    return true;
                }
                return false;
            case 'object':
                if (null === v) {
                    return true;
                } else if (undefined !== v.length && v.length === 0) {
                    return true;
                } else {
                    for (var k in v) {
                        return false;
                    }
                    return true;
                }
            default:
                return false;
        }
    },
    getClientIp: function (req) {
        var ip = req.headers['x-forwarded-for'] ||
            req.connection.remoteAddress ||
            req.socket.remoteAddress ||
            req.connection.socket.remoteAddress;
        return ip.replace(/::ffff:/g, "")
    },
    getWeChatSign: function (params) {
        let pair = [];
        Object.keys(params).sort((a, b) => a > b).forEach(key => {
            params[key] && pair.push(`${key}=${params[key]}`)
        });
        pair.push("key=inveno2017inveno2017inveno2017in");
        return md5(pair.join("&")).toUpperCase()
    }
}

module.exports = utils
