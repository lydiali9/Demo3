// modules
module.exports = {
    IVN_ACTIVITY: {
        key:  "5b20d3eca1ef16e149c94037",
        value: "最新活动来了，赶快看看吧！"
    },
    IVN_EXPRESS: {
        key:  "5b2105b4a1ef16e149c94038",
        value: "亲，您的快递信息已更新！"
    },
    IVN_VIOLATION: {
        key: "5b210e9fa1ef16e149c94039",
        value: "亲，您近期有违章待处理！"
    }
}