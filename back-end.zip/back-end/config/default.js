'use strict';

module.exports = {
    port: 8081,
    url: 'mongodb://localhost:27017/pie_media',
    session: {
        name: 'SID',
        secret: 'SID',
        cookie: {
            httpOnly: true,
            secure: true,
            maxAge: 365 * 24 * 60 * 60 * 1000
        }
    },
    // 寻医问药url
    sickUrl: 'http://test.api.wws.xywy.com/',
    sickSecret: 'ZuIQ66FXi7vEshPxVpHByJcgRXvqxqyY',
    sickSource: 'ywb',
    sickAccountUrl: 'https://passport.xywy.com/partner/partner_login_sp',
    sickAccountKey: 'F0NqcJVVCzhBVHThHIUI7HR3',
    sickAccountIV: 'NUAKHbIf',
    sickAccountPname: 'yingweinuo',
    sickAccountSname: 'yygh'
};
