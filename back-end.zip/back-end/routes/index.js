'use strict';

let express = require('express');
let multer = require('multer');
let $api = require('../api');
let upload = multer({ dest: './upload' });
// let upload = multer({ dest: '/upload' });
let $activity = require('../controller/activity/activityManager');
let $exprssage = require('../controller/expressage/expressageManager');
let $reputation = require('../controller/reputation/reputationManager');
let $vehicle = require('../controller/vehicle/vehicleManager');
let $user = require('../controller/user/userManager');
let $common = require('../controller/common/common');
let $servicebehavior = require('../controller/serviceBehavior/serviceBehaviorManager');
let $service = require('../controller/service/serviceManager');
let $sick = require('../controller/sick');
let verifyToken = require('../utils/verifyToken');
let $order = require('../controller/medical/order');
let router = express.Router();

// activity
router.get($api.query_activity, $activity.queryActivity);
router.get($api.get_activity, $activity.getActivity);

// expressage
router.get($api.get_expressage, $exprssage.getExpressage);

// reputation
router.post($api.get_reputation, $reputation.getReputation);
router.post($api.get_pub_permissions_name, $reputation.getPubPermissionsName);

// vehicle
router.get($api.get_vehicle_violation, $vehicle.getVehicle);
router.post($api.add_vehicle, $vehicle.addVehicle);
router.post($api.update_vehicle, $vehicle.updateVehicle);
router.post($api.delete_vehicle, $vehicle.deleteVehicle);
router.get($api.query_vehicle_count, $vehicle.queryVehicleCount);
router.get($api.get_vehicle_by_id, $vehicle.getVehicleById);

// code
router.get($api.get_code, $user.getCode);

// area
router.get($api.query_area, $common.queryArea);

// user
router.post($api.login, $user.login);
router.get($api.get_user, verifyToken, $user.getUser);
router.post($api.update_user, verifyToken, $user.updateUser);

// service behavior
router.get($api.get_service_behavior, $servicebehavior.getServiceBehavior);

// service
router.get($api.query_service, $service.queryService);

// common
router.post($api.images_upload, upload.array('file'), $common.imagesUpload);

router.get($api.get_position, $common.getPosition);

router.post($api.wxPay, $order.wxPay);
router.get($api.get_order_status, $order.getOrderStatus);
router.post($api.wxpay_notify, $order.wxpayNotify);

// 寻医问药
router.post($api.sick_question, verifyToken, $sick.postQuestion);
router.get($api.sick_questions, verifyToken, $sick.getQuestion);
router.get($api.sick_questionId, verifyToken, $sick.getQuestion);
router.delete($api.sick_questionId, verifyToken, $sick.deleteQuestion);

router.post($api.sick_question_append, verifyToken, $sick.postQuestionAppend);

router.get($api.sick_question_append, verifyToken, $sick.getQuestionAppend);
router.get($api.sick_account_login, verifyToken, $sick.getAccount);

router.post($api.sick_patientId, verifyToken, $sick.postPatient);
router.get($api.sick_patientId, verifyToken, $sick.getPatient);
router.delete($api.sick_patientId, verifyToken, $sick.deletePatient);
router.get($api.sick_patients, verifyToken, $sick.getPatient);
router.post($api.sick_patient, verifyToken, $sick.postPatient);

router.post($api.sick_reward, verifyToken, $sick.postReward);
router.post($api.sick_comment, verifyToken, $sick.postComment);

router.post($api.sick_question_status, $sick.postQuestionStatus);
router.post($api.sick_order_status, $sick.postOrderStatus);
router.post($api.sick_order_refund, $sick.postOrderRefund);

module.exports = router;
