'use strict';

let mongoose = require('mongoose');

const Schema = mongoose.Schema;

const orderSchema = new Schema({
    order_id: { type: String },
    uid: Schema.Types.ObjectId,
    money: Number,
    status: { type: Number, default: 0 },
    is_written_off: { type: Number, default: 0 },
    // 1、未核销线上退款，2、已核销资源方线下退款
    refund_type: { type: Number, default: 0 },
    pay_type: { type: String },
    fee_type:{ type: Number, default: 1 },
    create_time: { type: Date, default: Date.now },
    update_time: { type: Date, default: Date.now },
})

const Order = mongoose.model('order', orderSchema);

module.exports = Order
