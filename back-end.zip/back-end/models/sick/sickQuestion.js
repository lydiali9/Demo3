const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const contentSchema = new Schema({
    type: String,
    text: String,
    _id: false
});

const sickQuestionSchema = new Schema({
    createTime: { type: Date, default: Date.now },
    updateTime: { type: Date, default: Date.now },
    qid: { type: Number, default: Date.now() },
    doctorIds: String,
    content: String,
    patientId: Schema.Types.ObjectId,
    patientName: String,
    patientAge: Number,
    patientAgeMonth: Number,
    patientAgeDay: Number,
    patientPhone: Number,
    patientSex: Number,
    payAmount: Number,
    payType: Number,
    picUrls: Array,
    qType: Number,
    uid: Schema.Types.ObjectId,
    orderId: String,
    /**
     * 退款状态
     */
    refundStatus: { type: Number, default: 0 },
    expertData: {
        expertId: String,
        expertName: String,
        expertDepartment: String,
        expertLevel: String,
        expertHospital: String,
        expertPic: String,
        recIndex: String,
        goodAt: String,
        practiceExperience: String
    },
    /**
     *  对方透传过来的数据
     * 1正常回复，2关闭问题，3回复医嘱。
     * （1）医生回复后，医生可以主动关闭该问题；
     * （2）距问题提问时间最多48小时系统自动关闭（资源方控制）；
     * （3）合作方平台超时关闭，如问题48小时内没有收到回复，自动关闭。（合作方控制）；
     */
    handleType: Number,
    messageList: [
        {
            _id: false,
            msgId: String,
            content: contentSchema,
            msgType: Number,
            createTime: Date
        }
    ]
});

sickQuestionSchema.index({ qid: 1 });
const SickQuestion = mongoose.model('SickQuestion', sickQuestionSchema);

module.exports = SickQuestion;
