const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const doctorsSchema = new Schema({
    createTime: { type: Date, default: Date.now },
    updateTime: { type: Date, default: Date.now },
    expertId: String,
    expertName: String,
    expertDepartment: String,
    expertLevel: String,
    expertHospital: String,
    expertPic: String,
    recIndex: String,
    goodAt: String,
    practiceExperience: String
});

const doctors = mongoose.model('doctors', doctorsSchema);

module.exports = doctors;
