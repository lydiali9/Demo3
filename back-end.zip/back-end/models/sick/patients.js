const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const patientsSchema = new Schema({
    createTime: { type: Date, default: Date.now },
    updateTime: { type: Date, default: Date.now },
    patientAge: Number,
    patientAgeMonth: Number,
    patientAgeDay: Number,
    patientPhone: Number,
    patientSex: Number,
    patientName: String,
    uid: Schema.Types.ObjectId,
    isDelete: { type: Number, default: 0 }
});

const patients = mongoose.model('patients', patientsSchema);

module.exports = patients;
