/**
 * Common
 * Created by yuhua.li
 */

let baiduMap = require('baidumap');
let $logger = require('../../utils/logger');
let $code = require('../../utils/code');
let areaList = require('../../prototype/data');
let bdmap = baiduMap.create({ 'ak': 'krP6kTQZyiYFo7OUwW535MKqeZnMZLLI' });
let os = require('os');
let crypto = require('crypto');
let path = require('path');
let fs = require('fs');
let http = require('http');

function upload(file) {
    return new Promise(function (resolve, reject) {
        let filePathNow = file && file.path;
        if(filePathNow == null){
            reject('上传图片失败');
        }
        let absolutePath;
        if (os.platform() == 'linux') {
            absolutePath = path.resolve('.', filePathNow);
        } else {
            absolutePath = path.resolve(__dirname, '..', filePathNow);
        }
        let timestamp = new Date().getTime();
        let uid = Math.random().toString().slice(2, 18) + Math.random().toString().slice(2, 18);
        let postUrl = '/upload?app=adconf&uid=' + uid + '&tm=' + timestamp + '&tk=';
        let tk_src_prefix = 'adconf:' + uid + ":" + timestamp + ':34F<S932JF;<,/SF*F56#DSfd+9fw?zF:';

        fs.readFile(absolutePath, function (err, data) {
            if (err) {
                return reject('上传图片失败')
            }
            console.log("uploadImage:fileName === " + absolutePath + "; fileSize === " + data.length);
            let hash = crypto.createHash('md5');
            hash.update(tk_src_prefix);
            hash.update(data);
            postUrl += hash.digest('hex');
            let option = {
                method: 'post',
                host: 'upload.inveno.com',
                port: '80',
                path: postUrl,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "Content-Length": data.length,
                }
            }

            let req = http.request(option, function (response) {
                console.log("uploatImage: response.statusCode === " + response.statusCode);
                if (response.statusCode == 200) {
                    var responseBody = '';
                    response.on('data', function (data) {
                        responseBody += data;
                    });
                    response.on('end', function () {
                        console.log("uploatImage: responseBody === " + responseBody);
                        try {
                            let jsonBody = JSON.parse(responseBody);
                            if (jsonBody.url) {
                                resolve(jsonBody.url + "&quality=raw")
                            } else {
                                reject('上传图片失败')
                            }
                        } catch (e) {
                            reject('上传图片失败')
                        }
                    });
                }
            });

            req.write(data);
            req.end();
        });
    })
}

module.exports = {
    queryArea(req, res) {
        res.json({ code: $code.SUCCESS, msg: 'success', content: areaList });
    },

    imagesUpload(req, res) {
        if (req.files == null) {
            $logger.error('method: getOrder, msg: 请求信息不完整');
            return res.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", content: {} });
        }

        Promise.all(req.files.map(file => upload(file))).then(picUrls => {
            res.json({
                code: $code.SUCCESS,
                msg: 'success',
                content: {
                    picUrls
                }
            });
        }).catch(e => {
            $logger.error("图片上传出错：" + e);
            res.json({
                code: $code.FALSE,
                msg: 'fail',
                content: {}
            });
        })
    },
    getPosition(req, res) {
        let { longitude, latitude } = req.query;
        let reverseGeocoderOption = { 'location': `${latitude},${longitude}`, 'pois': 1 };
        bdmap.reverseGeocoder(reverseGeocoderOption, function (err, result) {
            if (err) {
                res.json({ code: $code.FALSE, msg: '定位失败' });
            } else {
                try {
                    const data = result && JSON.parse(result) || {}
                    res.json({ code: $code.SUCCESS, msg: 'success', content: data.result && data.result.addressComponent });
                } catch (e) {
                    res.json({ code: $code.FALSE, msg: '定位失败' });
                }
            }
        });
    }
}




