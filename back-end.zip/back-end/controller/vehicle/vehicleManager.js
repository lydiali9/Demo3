/**
 * vehicle
 * @type {es}
 * Created by yuhua.li
 */
var request_promise = require('request-promise');
const puppeteer = require('puppeteer');
var cheerio = require('cheerio');

let $url = require('../../utils/urls');
let $logger = require('../../utils/logger');
let $code = require('../../utils/code');
let VehicleModel = require('../../models/vehicle/vehicle');

let $modelConfig = require('../../utils/modelConfig');
let ServiceBehaviorManager = require("../serviceBehavior/serviceBehaviorManager");
let cacheRecords = {};
let browser = ""
async function initPage() {
    browser = await puppeteer.launch({args: ['--no-sandbox', '--disable-setuid-sandbox']});
}
initPage();

function getViolationCount(body) {
    return new Promise(function (resolve, reject) {
        let url = $url.get_violation_html + "?carno=" + body.plate_no + "&vin=" +
            body.VIN + "&engine=" + body.engine_no + "&car_type=" + body.vehicle_type;
        try {
            (async () => {
                const page = await browser.newPage();
                await page.goto(url);
           
                page.on('requestfinished', request => {

                    if (request._resourceType == "xhr") {
                        // 匹配所需数据的请求地址
                        if (request._url.indexOf('https://mys4s.cn/v3/violation/web/query') != -1) {
                            (async () => {
                                try {
                                    // 获取数据并转为json格式
                                    let res = await request.response();
                                    let result = await res.json();
                                    let data;
                                    if (result.code == 0) {
                                        let res_data = result.data;
                                        data = {
                                            fine: res_data.Fine,
                                            point: res_data.Degree,
                                            total: res_data.Total
                                        }

                                        let list = res_data.Records.map(item => ({
                                            address: item.Address,
                                            occTime: item.OccTime,
                                            reason: item.Reason,
                                            fine: item.Fine,
                                            point: item.Point,
                                            violationCode: item.ViolationCode,
                                            violationWritNo: item.ViolationWritNo
                                        }))
                                        cacheRecords[body.plate_no] = {
                                            VIN: body.VIN,
                                            engine_no: body.engine_no,
                                            vehicle_type: body.vehicle_type,
                                            plate_no: body.plate_no,
                                            Records: list
                                        }
                                    } else {
                                        data = {
                                            fine: 0,
                                            point: 0,
                                            total: 0
                                        }
                                        cacheRecords[body.plate_no] = {
                                            VIN: body.VIN,
                                            engine_no: body.engine_no,
                                            vehicle_type: body.vehicle_type,
                                            plate_no: body.plate_no,
                                            Records: []
                                        }
                                    }
                                    $logger.info('method: get_violation_count, msg: 爬取信息成功， result:' + result);
                                    await page.close();
                                    return resolve(data);
                                } catch (err) {
                                    await page.close();
                                    $logger.error('method: query_violation, msg: ' + err);
                                    return reject(err)
                                }
                            })()
                        }
                    }
                });
            })()
        } catch (err) {
            return reject(err)
        }

    });
}

function getViolation(body) {
    return new Promise(function (resolve, reject) {

        let url = $url.get_violation_html + "?carno=" + body.plate_no + "&vin=" +
            body.VIN + "&engine=" + body.engine_no + "&car_type=" + body.vehicle_type;

        if (cacheRecords[body.plate_no]) {
            return resolve(cacheRecords[body.plate_no]);
        }

        try {
            (async () => {
                const page = await browser.newPage();
                await page.goto(url);

                page.on('requestfinished', request => {

                    if (request._resourceType == "xhr") {
                        // 匹配所需数据的请求地址
                        if (request._url.indexOf('https://mys4s.cn/v3/violation/web/query') != -1) {
                            (async () => {
                                try {
                                    // 获取数据并转为json格式
                                    let res = await request.response();
                                    let result = await res.json();
                                    let data;
                                    if (result.code == 0) {
                                        let res_data = result.data
                                        let list = res_data.Records.map(item => ({
                                            address: item.Address,
                                            occTime: item.OccTime,
                                            reason: item.Reason,
                                            fine: item.Fine,
                                            point: item.Point,
                                            violationCode: item.ViolationCode,
                                            violationWritNo: item.ViolationWritNo
                                        }))

                                        data = {
                                            VIN: body.VIN,
                                            engine_no: body.engine_no,
                                            vehicle_type: body.vehicle_type,
                                            plate_no: body.plate_no,
                                            Records: list
                                        }

                                    } else {
                                        data = {
                                            VIN: body.VIN,
                                            engine_no: body.engine_no,
                                            vehicle_type: body.vehicle_type,
                                            plate_no: body.plate_no,
                                            Records: []
                                        }
                                    }
                                    $logger.info('method: get_violation, msg: 爬取信息成功， result:' + data);
                                    await page.close();
                                    return resolve(data);

                                } catch (err) {
                                    await page.close();
                                    $logger.error('method: query_violation, msg: ' + err);
                                    return reject(err)
                                }
                            })()
                        }
                    }
                });
            })()
        } catch (err) {
            return reject(err)
        }
    });
}

module.exports = {

    getVehicle(req, res) {
        let body = req.query;

        if (body.vehicle_type && body.engine_no && body.VIN && body.plate_no) {
            $logger.info('method: get_violation, msg: 开始爬取车辆信息');
            getViolation(body)
                .then((result) => {

                    if (!!result) {
                        // validate if the uid is exists, create behavior, otherwise create an new user then create behavior
                        let params = {
                            service_id: $modelConfig.IVN_VIOLATION.key,
                            name: $modelConfig.IVN_VIOLATION.value,
                            behavior_type: 1,
                            keyword: JSON.stringify(body),
                        }

                        ServiceBehaviorManager.createServiceBehavior(params, body.uid)
                            .then(uid => {
                                res.json({ code: $code.SUCCESS, msg: 'success', content: Object.assign(result, { uid: uid }) });
                            })
                            .catch(function (err) {
                                $logger.error('method: get_violation成功后，创建用户行为失败, msg: ' + err);
                                res.json({ code: $code.SUCCESS, msg: 'success', content: Object.assign(result, { uid: !!body.uid ? body.uid : "" }) });
                            });

                    } else {
                        $logger.error('method: get_vehicle, msg: 获取车辆违章信息失败');
                        res.json({ code: $code.FALSE, msg: "获取车辆违章信息失败", data: "" });
                    }
                })
                .catch(function (err) {
                    $logger.error('method: get_vehicle, msg: ' + err);
                    res.json({ code: $code.FALSE, msg: 'failed', err: err });
                });
        } else {
            $logger.warn('method: get_vehicle, msg: 请求信息不完整');
            res.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", data: "" });
        }
    },

    addVehicle(req, res) {
        let body = req.body;

        if (body.vehicle_type && body.plate_no && body.VIN && body.engine_no && body.uid) {
            // validate if the vehicle is exists
            let params = {
                vehicle_type: body.vehicle_type,
                uid: body.uid,
                plate_no: body.plate_no,
                VIN: body.VIN,
                engine_no: body.engine_no
            }
            VehicleModel.findOne(params, function (err, result) {
                if (!result) {
                    // save the data of vehicle
                    VehicleModel.create(params, function (error, docs) {
                        if (err) {
                            $logger.error('method: add_vehicle, msg: 添加车辆失败');
                            res.json({ code: $code.FALSE, msg: "添加车辆失败", data: "" });
                        } else {
                            res.json({ code: $code.SUCCESS, msg: '添加车辆成功', content: docs });
                        }
                    });
                } else {
                    $logger.warn('method: add_vehicle, msg: ' + body.plate_no + ' 车辆已经添加');
                    res.json({ code: $code.REPETITION, msg: "此车辆已经添加", data: "" });
                }
            });
        } else {
            $logger.warn('method: add_vehicle, msg: 请求信息不完整');
            res.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", data: "" });
        }
    },

    updateVehicle(req, res) {
        let body = req.body;

        if (body.vehicle_type && body.plate_no && body.VIN && body.engine_no && body.uid && body._id) {
            // validate if the vehicle is exists
            let params = {
                vehicle_type: body.vehicle_type,
                plate_no: body.plate_no,
                VIN: body.VIN,
                engine_no: body.engine_no
            }
            VehicleModel.findById(body._id, function (err, result) {
                if (result) {
                    // update the data of vehicle
                    VehicleModel.update({ _id: body._id, uid: body.uid }, params, function (error, docs) {
                        if (err) {
                            $logger.error('method: update_vehicle, msg: 修改车辆失败' + err);
                            res.json({ code: $code.FALSE, msg: "修改车辆失败", data: "" });
                        } else {
                            res.json({ code: $code.SUCCESS, msg: '修改车辆成功', content: docs });
                        }
                    });
                } else {
                    $logger.warn('method: update_vehicle, msg: id为' + body._id + '的车辆不存在');
                    res.json({ code: $code.NO_EXIST, msg: "此车辆不存在或已被删除", data: "" });
                }
            });
        } else {
            $logger.warn('method: update_vehicle, msg: 请求信息不完整');
            res.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", data: "" });
        }
    },

    deleteVehicle(req, res) {
        let body = req.body;

        if (body._id && body.uid) {
            // validate if the vehicle is exists

            VehicleModel.findById(body._id, function (err, result) {
                if (result) {
                    // update the data of vehicle
                    VehicleModel.remove({ _id: body._id, uid: body.uid }, function (error, docs) {
                        if (err) {
                            $logger.error('method: delete_vehicle, msg: 删除车辆失败' + err);
                            res.json({ code: $code.FALSE, msg: "删除车辆失败", data: "" });
                        } else {
                            res.json({ code: $code.SUCCESS, msg: '删除车辆成功', content: docs });
                        }
                    });
                } else {
                    $logger.warn('method: delete_vehicle, msg: id为' + body._id + '的车辆不存在');
                    res.json({ code: $code.NO_EXIST, msg: "此车辆不存在或已被删除", data: "" });
                }
            });
        } else {
            $logger.warn('method: delete_vehicle, msg: 请求信息不完整');
            res.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", data: "" });
        }
    },

    queryVehicleCount(req, res) {
        let body = req.query;

        if (body.uid) {
            // search if there are any vehicles.
            VehicleModel.find({ uid: body.uid }, function (err, results) {
                if (err) {
                    $logger.error('method: query_vehicle, msg: 该用户尚未添加车辆');
                    res.json({ code: $code.NO_EXIST, msg: '该用户尚未添加车辆', content: {} });
                } else {
                    let content = [];

                    results.forEach(function (result) {
                        getViolationCount(result)
                            .then(function (data) {
                                let fields = {
                                    fine: data.fine,
                                    point: data.point,
                                    total: data.total,
                                }
                                let vehicle = result && result._doc ? result._doc : {};
                                content.push(Object.assign(vehicle, fields));
                                if(content.length == results.length){
                                    res.json({ code: $code.SUCCESS, msg: '查询车辆违章信息成功', content: content });
                                }
                            })
                            .catch(function (err) {
                                $logger.error('method: query_vehicle, msg: 根据用户添加车辆查询相关违章信息失败');
                                res.json({ code: $code.REQUEST_DATA_ERR, msg: err, data: "" });
                            });
                    });
                }
            });
        } else {
            $logger.warn('method: query_vehicle, msg: 请求信息不完整');
            res.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", data: "" });
        }
    },

    getVehicleById(req, res) {
        let body = req.query;

        if (body.id) {
            VehicleModel.findById(body.id, function (err, result) {
                if (err) {
                    $logger.error('method: get_vehicle_by_id, msg: The vehicle does not exists');
                    res.json({ code: $code.NO_EXIST, msg: 'The vehicle does not exists', content: {} });
                } else {
                    res.json({ code: $code.SUCCESS, msg: '查询车辆信息成功', content: result });
                }
            });
        } else {
            $logger.warn('method: get_vehicle_by_id, msg: 请求信息不完整');
            res.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", data: "" });
        }
    }
};
