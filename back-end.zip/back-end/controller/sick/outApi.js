const urljoin = require('url-join');
const requestPromise = require('request-promise');
const stringNaturalCompare = require('string-natural-compare');
const hump = require('humps');
const md5 = require('md5');
const querystring = require('querystring');
const logger = require('../../utils/logger');
const config = require('../../config/default');
const crypto = require('crypto');
const Base64 = require('js-base64').Base64;

function concatUrl(relativeUrl) {
    const URL_PREFIX = config.sickUrl;
    const API_VERSION = '1.1';
    return urljoin(URL_PREFIX, relativeUrl, API_VERSION);
}

/**
 *
 * @param {Object} body
 * @returns {Object}
 */
function makeSign(body) {
    let signStr = sign(body);
    return Object.assign(
        {
            sign: signStr
        },
        body
    );
}

function sign(body) {
    let signStr = Object.keys(body)
        .sort(stringNaturalCompare.caseInsensitive)
        .map(key => `${key}=${body[key]}`)
        .join('&');
    let sign = md5(signStr + config.sickSecret);
    return sign;
}

function desEncrypt(plaintext) {
    const key = config.sickAccountKey;
    const iv = config.sickAccountIV;
    const cipher = crypto.createCipheriv('des-ede3-cbc', key, iv);
    cipher.setAutoPadding(true);

    let encryptText = cipher.update(plaintext, 'utf8', 'base64');
    encryptText += cipher.final('base64');
    return encryptText;
}

async function post(url, requestBody) {
    try {
        requestBody = Object.assign(
            {
                atime: parseInt(Date.now() / 1000),
                source: config.sickSource
            },
            hump.decamelizeKeys(requestBody)
        );
        requestBody = deleteUndefined(requestBody);
        requestBody = makeSign(requestBody);
        let timeBegin = Date.now();
        let resp = await requestPromise(url, {
            method: 'POST',
            form: requestBody,
            json: true,
            timeout: 5000
        });
        logger.info('req url: %s, body: %j, resp: %j, cost: %dms', url, requestBody, resp, Date.now() - timeBegin);
        if (resp.code === 10000) {
            return resp.data;
        }
    } catch (error) {
        logger.info('req url: %s, body: %j, error', url, requestBody);
        logger.error(error);
    }
    throw new Error('第三方服务异常');
}

function deleteUndefined(obj) {
    let ret = {};
    Object.keys(obj).forEach(key => {
        if (typeof obj[key] !== 'undefined') {
            ret[key] = obj[key];
        }
    });
    return ret;
}

class OutApi {
    constructor() {
        for (const key of Object.getOwnPropertyNames(this.constructor.prototype)) {
            if (typeof this[key] === 'function' && key !== 'constructor') {
                this[key] = this[key].bind(this);
            }
        }
    }
    async verifySign(body) {
        let { sign: signStr, ...bodyRest } = body;
        let localSign = sign(bodyRest);
        console.log(signStr, localSign);
        return signStr == localSign;
    }
    async askQuestion(question) {
        const URL = concatUrl('rtqa_service/question/ask');
        return post(URL, question);
    }
    async appendQueston(questionAppend) {
        const URL = concatUrl('rtqa_service/question/add');
        return post(URL, questionAppend);
    }
    async reward(reward) {
        const URL = concatUrl('rtqa_service/question/reward');
        return post(URL, reward);
    }
    async comment(comment) {
        const URL = concatUrl('rtqa_service/question/comment');
        return post(URL, comment);
    }
    async deleteQuestion(question) {
        const URL = concatUrl('rtqa_service/question/del');
        return post(URL, question);
    }
    createLoginUrl(uid) {
        const URL = config.sickAccountUrl;
        let enkey = desEncrypt(
            JSON.stringify({
                puid: uid,
                timestamp: Math.round(Date.now() / 1000)
            })
        );
        enkey = Base64.encode(enkey);
        let url =
            URL +
            '?' +
            querystring.stringify(
                {
                    pname: config.sickAccountPname,
                    sname: config.sickAccountSname,
                    enkey
                },
                null,
                null,
                {
                    encodeURIComponent: str => str
                }
            );
        logger.info('redirect url: ' + url);
        return url;
    }
}

module.exports = new OutApi();
