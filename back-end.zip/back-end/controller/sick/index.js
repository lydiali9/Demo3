const typeCheck = require('type-check').typeCheck;
const hump = require('humps');
const outApi = require('./outApi');
const ResponseCode = require('../../utils/code');
const UserModel = require('../../models/user/user');
const SickQuestionModel = require('../../models/sick/sickQuestion');
const PatientsModel = require('../../models/sick/patients');
const DoctorsModel = require('../../models/sick/doctors');
const OrderModel = require('../../models/medical/order');
const logger = require('../../utils/logger');
const util = require('util');

/**
 *
 * @typedef {import('express').Request} Request
 * @typedef {import('express').Response} Response
 */

function getUser(req) {
    return UserModel.findById(req.decoded.id).then(user => {
        if (!user) {
            throw new Error('找不到该用户');
        }
        return user;
    });
}

function checkParams(obj, typedef) {
    Object.keys(typedef).forEach(key => {
        let checkSuccess = typeCheck(typedef[key], obj[key]);
        if (!checkSuccess) {
            let err = new Error(`${key} should be ${typedef[key]}`);
            err.code = ResponseCode.REQUEST_DATA_ERR;
            throw err;
        }
    });
    return true;
}

const SYSTEM_MESSAGE_CODE_IN_CHAT = {
    // 送心意
    SEND_HEART: 100,
    // 普通系统提示
    COMMON_TIP: 110,
    // 评论
    COMMEND: 120,
    END: 200
};

const QUESTION_STATUS = {
    // 已支付
    PAID: 1,
    // 已完成
    COMPLETED: 2,
    // 已关闭
    CLOSED: 3,
    // 未知
    UN_KNOWN: -1
};
function parseQuestionStatus(question) {
    if (question.orderId) {
        if (question.refundStatus != 0) {
            return QUESTION_STATUS.CLOSED;
        }
        if (question.handleType == 2) {
            return QUESTION_STATUS.COMPLETED;
        }
        return QUESTION_STATUS.PAID;
    }
    return QUESTION_STATUS.UN_KNOWN;
}

/**
 * handler进行业务逻辑处理， 异常直接抛出，不处理响应
 * @param {Request} req
 * @param {Response} res
 * @param {Object} paramsChecked
 * @param {()=>Promise} handler
 */
function wrapThirdResponse(req, res, paramsChecked, handler) {
    return Promise.resolve(req.body)
        .then(data => {
            logger.info(
                util.format('wrapThirdResponse %j \n %j \n  %j \n %j', req.body, req.rawHeaders, req.query, req.params)
            );
            checkParams(data, paramsChecked);
            return outApi
                .verifySign(data)
                .then(success => {
                    if (success) {
                        return data;
                    }
                    let err = new Error('签名失败');
                    err.code = ResponseCode.REQUEST_DATA_ERR;
                    throw err;
                })
                .then(() => hump.camelizeKeys(data));
        })
        .then(data => handler(data))
        .then(() => {
            res.status(200).json({
                code: ResponseCode.SUCCESS,
                message: 'success'
            });
        })
        .catch(err => {
            logger.error(err);
            let respData = {
                code: ResponseCode.INTERNAL_SERVER_ERROR,
                message: '服务端异常'
            };
            if (err.code) {
                respData = {
                    code: err.code,
                    message: err.message
                };
            }
            res.status(200).json(respData);
        });
}

/**
 *
 * @param {Express.Response} res
 */
function errHandler(res) {
    return err => {
        logger.error(err);
        res.status(200).json({
            code: err.code || ResponseCode.INTERNAL_SERVER_ERROR,
            message: err.code ? err.message : '服务端异常'
        });
    };
}

/**
 *
 * @param {Express.Response} res
 */
function successHandler(res) {
    return data => {
        let respData = {
            code: ResponseCode.SUCCESS
        };
        if (data) {
            respData.content = data;
        } else {
            respData.message = 'success';
        }
        res.status(200).json(respData);
    };
}

function stringifyContent(content) {
    let ret = { type: content.type };
    if (content.type == 'image') {
        ret.file = content.text;
    } else {
        ret.text = content.text;
    }
    return JSON.stringify(ret);
}

function parseContent(contentStr) {
    let content = JSON.parse(contentStr);
    return {
        type: content.type,
        text: content.file || content.text
    };
}

const OrderStatus = {
    NOT_PAY: 0,
    PAY_COMPLETE: 1
};

/**
 * 验证订单信息
 * @param {Object} payInfo
 * @param {String} payInfo.orderId
 * @param {Number} payInfo.money
 * @param {Object} extraData 额外信息
 */
function verifyOrder(payInfo, extraData) {
    return OrderModel.findOne({ order_id: payInfo.orderId })
        .then(doc => {
            let err;
            if (!doc) {
                err = new Error('找不到支付订单信息');
            } else if (doc.status !== OrderStatus.PAY_COMPLETE) {
                err = new Error('该订单未支付');
            } else if (doc.money < payInfo.money) {
                err = new Error('订单金额错误');
            } else if (doc.is_written_off) {
                err = new Error('订单已被核销');
            }
            if (err) {
                err.code = ResponseCode.REQUEST_DATA_ERR;
                throw err;
            }
        })
        .then(() => extraData);
}

class Sick {
    constructor() {
        for (const key of Object.getOwnPropertyNames(this.constructor.prototype)) {
            if (typeof this[key] === 'function' && key !== 'constructor') {
                this[key] = this[key].bind(this);
            }
        }
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    getQuestion(req, res) {
        let qid = req.params['qid'];
        getUser(req)
            .then(user => {
                let limit = parseInt(req.query['limit'] || 100);
                let offset = parseInt(req.query['offset'] || 0);
                let condition = { uid: user._id };
                if (qid) {
                    condition.qid = qid;
                }
                return SickQuestionModel.find(condition)
                    .skip(offset)
                    .limit(limit)
                    .select({
                        qid: 1,
                        content: 1,
                        createTime: 1,
                        patientAgeMonth: 1,
                        patientAgeDay: 1,
                        patientPhone: 1,
                        patientSex: 1,
                        patientName: 1,
                        payAmount: 1,
                        picUrls: 1,
                        patientId: 1,
                        expertData: 1,
                        refundStatus: 1,
                        orderId: 1,
                        handleType: 1,
                        _id: 0
                    });
            })
            .then(docs =>
                docs.map(({ _doc: doc }) => {
                    let status = parseQuestionStatus(doc);
                    let { orderId, handleType, refundStatus, ...restDoc } = doc;
                    return Object.assign(
                        {
                            status
                        },
                        restDoc
                    );
                })
            )
            .then(docs => {
                if (qid) {
                    if (docs.length > 0) {
                        return docs[0];
                    } else {
                        let error = new Error('找不到该记录');
                        error.code = ResponseCode.NO_FOUND;
                        throw error;
                    }
                }
                return docs;
            })
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    postQuestion(req, res) {
        getUser(req)
            .then(user => {
                let question = req.body;
                checkParams(question, {
                    content: 'String',
                    patientId: 'String',
                    payAmount: 'Number',
                    payType: 'Number',
                    picUrls: '[String] | Undefined',
                    orderId: 'String'
                });
                return PatientsModel.findOne({ uid: user._id, _id: question.patientId })
                    .select({
                        patientAge: 1,
                        patientAgeMonth: 1,
                        patientAgeDay: 1,
                        patientPhone: 1,
                        patientSex: 1,
                        patientName: 1,
                        _id: 0
                    })
                    .then(patient => {
                        if (!patient) {
                            let error = new Error('找不到该患者');
                            error.code = ResponseCode.NO_FOUND;
                            throw error;
                        }
                        return Object.assign(
                            {
                                uid: user._id + '',
                                qid: Date.now()
                            },
                            question,
                            patient._doc,
                            {
                                picUrls:
                                    !question.picUrls || (question.picUrls && question.picUrls.length == 0)
                                        ? undefined
                                        : question.picUrls
                            }
                        );
                    });
            })
            .then(question => verifyOrder({ orderId: question.orderId, money: question.payAmount }, question))
            .then(question => SickQuestionModel.create(question).then(() => question))
            .then(question =>
                outApi
                    .askQuestion(
                        Object.assign({}, question, {
                            ip: req.hostname,
                            picUrls: question.picUrls ? JSON.stringify(question.picUrls) : '',
                            qType: 2
                        })
                    )
                    .then(
                        () => ({
                            qid: question.qid
                        }),
                        err => {
                            SickQuestionModel.deleteOne({ qid: question.qid }).catch(error => logger.error(error));
                            throw err;
                        }
                    )
            )
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    deleteQuestion(req, res) {
        getUser(req)
            .then(user => {
                let qid = Number(req.params['qid']);
                return SickQuestionModel.findOne({ qid, uid: user._id }).then(question => {
                    if (question) {
                        return { qid, uid: question.patientId + '' };
                    }
                    let error = new Error('找不到该问题');
                    error.code = ResponseCode.NO_FOUND;
                    throw error;
                });
            })
            .then(question => outApi.deleteQuestion(question))
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    postPatient(req, res) {
        getUser(req)
            .then(user => {
                let patient = req.body;
                let patientId = req.params['patientId'];

                checkParams(patient, {
                    patientAge: 'Number',
                    patientAgeMonth: 'Number | Undefined',
                    patientAgeDay: 'Number | Undefined',
                    patientPhone: 'Number',
                    patientSex: 'Number',
                    patientName: 'String'
                });
                patient = Object.assign(
                    {
                        uid: user._id
                    },
                    patient
                );
                return patientId
                    ? PatientsModel.count({
                          uid: user._id,
                          patientName: patient.patientName,
                          _id: {
                              $ne: patientId
                          }
                      }).then(count => {
                          if (count > 0) {
                              let err = new Error('患者姓名重复');
                              err.code = ResponseCode.REQUEST_DATA_ERR;
                              throw err;
                          }
                          return PatientsModel.update({ _id: patientId, uid: user._id }, patient).then(doc => {
                              if (doc.n == 0) {
                                  let error = new Error('找不到该记录');
                                  error.code = ResponseCode.NO_FOUND;
                                  throw error;
                              }
                          });
                      })
                    : PatientsModel.count({ uid: user._id, patientName: patient.patientName }).then(count => {
                          if (count > 0) {
                              let err = new Error('患者姓名重复');
                              err.code = ResponseCode.REQUEST_DATA_ERR;
                              throw err;
                          }
                          return PatientsModel.create(patient).then(doc => ({
                              patientId: doc._id
                          }));
                      });
            })
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    deletePatient(req, res) {
        getUser(req)
            .then(user => {
                let patientId = req.params['patientId'];
                let condition = {
                    uid: user._id,
                    isDelete: 0,
                    _id: patientId
                };
                return PatientsModel.deleteOne(condition).then(doc => {
                    if (doc.n == 0) {
                        let error = new Error('找不到该记录');
                        error.code = ResponseCode.NO_FOUND;
                        throw error;
                    }
                });
            })
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    getPatient(req, res) {
        let patientId = req.params['patientId'];
        getUser(req)
            .then(user => {
                let limit = parseInt(req.query['limit'] || 100);
                let offset = parseInt(req.query['offset'] || 0);

                let condition = {
                    uid: user._id,
                    isDelete: 0
                };
                if (patientId) {
                    Object.assign(condition, { _id: patientId });
                }
                return PatientsModel.find(condition)
                    .sort({ createTime: -1 })
                    .skip(offset)
                    .limit(limit)
                    .select({
                        patientAge: 1,
                        patientAgeMonth: 1,
                        patientAgeDay: 1,
                        patientPhone: 1,
                        patientSex: 1,
                        patientName: 1
                    });
            })
            .then(docs => {
                if (patientId) {
                    if (docs.length > 0) {
                        let { _id, ...doc } = docs[0]._doc;
                        doc.patientId = _id;
                        return doc;
                    } else {
                        let error = new Error('找不到该记录');
                        error.code = ResponseCode.NO_FOUND;
                        throw error;
                    }
                }
                return docs.map(item => {
                    let { _id, ...doc } = item._doc;
                    return {
                        patientId: _id,
                        ...doc
                    };
                });
            })
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    getQuestionAppend(req, res) {
        let qid = Number(req.params['qid']);
        getUser(req)
            .then(user => {
                let limit = parseInt(req.query['limit'] || 100);
                let offset = parseInt(req.query['offset'] || -100);
                let condition = {
                    uid: user._id,
                    qid
                };
                return Promise.all([
                    SickQuestionModel.findOne(condition, {
                        messageList: {
                            $slice: [offset, limit]
                        }
                    }),
                    SickQuestionModel.aggregate([
                        {
                            $match: condition
                        },
                        {
                            $project: {
                                count: {
                                    $size: '$messageList'
                                }
                            }
                        }
                    ])
                ]);
            })
            .then(([doc, aggregateDoc]) => {
                if (!doc || aggregateDoc.length == 0) {
                    let error = new Error('找不到该记录');
                    error.code = ResponseCode.NO_FOUND;
                    throw error;
                }
                let count = aggregateDoc[0].count;
                return doc.messageList || [];
            })
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    postQuestionAppend(req, res) {
        getUser(req)
            .then(user => {
                let content = req.body;
                checkParams(content, {
                    text: 'String',
                    type: 'String'
                });
                if (['text', 'image'].indexOf(content.type) == -1) {
                    let err = new Error(`type must be 'text' or 'image'`);
                    err.code = ResponseCode.REQUEST_DATA_ERR;
                    throw err;
                }
                let qid = Number(req.params['qid']);
                return SickQuestionModel.findOne({ qid, uid: user._id }).then(question => {
                    if (question) {
                        return {
                            uid: user._id + '',
                            msgId: Date.now(),
                            content,
                            qid
                        };
                    }
                    let error = new Error('找不到该问题');
                    error.code = ResponseCode.NO_FOUND;
                    throw error;
                });
            })
            .then(questionAppend =>
                outApi
                    .appendQueston(
                        Object.assign({}, questionAppend, { content: stringifyContent(questionAppend.content) })
                    )
                    .then(() =>
                        SickQuestionModel.update(
                            { qid: questionAppend.qid, uid: questionAppend.uid },
                            {
                                $push: {
                                    messageList: Object.assign(
                                        {
                                            msgType: 1,
                                            createTime: new Date()
                                        },
                                        questionAppend
                                    )
                                }
                            }
                        )
                    )
                    .then(() => questionAppend)
            )
            .then(questionAppend => {
                if (questionAppend.content.type == 'text') {
                    /**
                     * @type {String}
                     */
                    let message = questionAppend.content.text;
                    let regexp = /(谢谢|感谢|感激|麻烦您了|辛苦了)/;
                    if (regexp.test(message)) {
                        SickQuestionModel.update(
                            { qid: questionAppend.qid, uid: questionAppend.uid },
                            {
                                $push: {
                                    messageList: {
                                        msgType: SYSTEM_MESSAGE_CODE_IN_CHAT.SEND_HEART,
                                        createTime: new Date(),
                                        msgId: Date.now(),
                                        content: { type: 'text', text: '亲，既然这么满意，要不给医生送个心意吧!' }
                                    }
                                }
                            }
                        ).exec();
                    }
                }
            })
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    postReward(req, res) {
        getUser(req)
            .then(user => {
                let reward = req.body;
                let qid = Number(req.params['qid']);
                checkParams(reward, {
                    orderId: 'String',
                    expertId: 'Number',
                    rewardAmount: 'Number',
                    rewardComment: 'String | Undefined'
                });
                return SickQuestionModel.findOne({ qid, uid: user._id }).then(question => {
                    if (question) {
                        return Object.assign(reward, { qid });
                    }
                    let error = new Error('找不到该问题');
                    error.code = ResponseCode.NO_FOUND;
                    throw error;
                });
            })
            .then(reward => verifyOrder({ orderId: reward.orderId, money: reward.rewardAmount }, reward))
            .then(reward => outApi.reward(reward))
            .then(() => {})
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    postComment(req, res) {
        getUser(req)
            .then(user => {
                let comment = req.body;
                let qid = Number(req.params['qid']);
                checkParams(comment, {
                    content: 'String',
                    expertId: 'Number',
                    star: 'Number',
                    tag: '[String] | Undefined'
                });
                return SickQuestionModel.findOne({ qid, uid: user._id }).then(question => {
                    if (question) {
                        return Object.assign(comment, {
                            qid,
                            tag: comment.tag ? JSON.stringify(comment.tag) : undefined
                        });
                    }
                    let error = new Error('找不到该问题');
                    error.code = ResponseCode.NO_FOUND;
                    throw error;
                });
            })
            .then(comment => outApi.comment(comment))
            .then(() => {})
            .then(successHandler(res))
            .catch(errHandler(res));
    }
    /**
     * 给第三方调用，同步提问信息
     * @param {Request} req
     * @param {Response} res
     */
    postQuestionStatus(req, res) {
        return wrapThirdResponse(
            req,
            res,
            {
                qid: 'Number|String',
                source: 'String',
                handle_type: 'Number | String',
                content: 'String | Undefined',
                expert_data: 'String',
                msg_id: 'String',
                atime: 'Number | String',
                sign: 'String'
            },
            question => {
                let expertData = {};
                try {
                    expertData = JSON.parse(question.expertData);
                } catch (error) {
                    let err = new Error('expert_data不能解析为JSON');
                    err.code = ResponseCode.REQUEST_DATA_ERR;
                    throw err;
                }
                checkParams(expertData, {
                    expert_id: 'Number|String',
                    expert_name: 'String',
                    expert_hospital: 'String'
                });
                return Promise.resolve(
                    Object.assign({}, question, {
                        expertData: hump.camelizeKeys(expertData),
                        qid: Number(question.qid),
                        handleType: Number(question.handleType)
                    })
                )
                    .then(question =>
                        SickQuestionModel.findOne({ qid: question.qid })
                            .select({ qid: 1, expertData: 1, handleType: 1 })
                            .then(result => {
                                if (!result) {
                                    let err = new Error('找不到该qid');
                                    err.code = ResponseCode.NO_FOUND;
                                    throw err;
                                }
                                if (result.handleType == 2) {
                                    let err = new Error('该问题已关闭');
                                    err.code = ResponseCode.REQUEST_DATA_ERR;
                                    throw err;
                                }
                                let isFirst = false;
                                if (!result.expertData.expertId) {
                                    isFirst = true;
                                }
                                return { question, isFirst };
                            })
                    )
                    .then(({ question, isFirst }) => {
                        let list = [];
                        if (isFirst) {
                            list.push({
                                msgType: SYSTEM_MESSAGE_CODE_IN_CHAT.COMMON_TIP,
                                createTime: new Date(),
                                msgId: Date.now(),
                                content: {
                                    type: 'text',
                                    text: `${question.expertData.expertName}医生很高兴为你服务！`
                                }
                            });
                        }
                        if (question.handleType == 2) {
                            list.push({
                                msgType: SYSTEM_MESSAGE_CODE_IN_CHAT.COMMEND,
                                createTime: new Date(),
                                msgId: Date.now()
                            });
                            list.push({
                                msgType: SYSTEM_MESSAGE_CODE_IN_CHAT.END,
                                createTime: new Date(),
                                msgId: Date.now()
                            });
                        } else {
                            list.push(
                                Object.assign({}, question, {
                                    msgType: 2,
                                    createTime: new Date(),
                                    content: parseContent(question.content)
                                })
                            );
                        }
                        return SickQuestionModel.update(
                            { qid: question.qid },
                            {
                                $push: {
                                    messageList: {
                                        $each: list
                                    }
                                },
                                handleType: question.handleType,
                                expertData: question.expertData
                            }
                        ).then(() => question);
                    })
                    .then(question =>
                        DoctorsModel.update(
                            { expertId: question.expertData.expertId },
                            Object.assign(
                                {
                                    updateTime: new Date()
                                },
                                question.expertData
                            ),
                            {
                                upsert: true
                            }
                        )
                    );
            }
        );
    }
    /**
     * 给第三方调用，同步订单信息
     * @param {Request} req
     * @param {Response} res
     */
    postOrderStatus(req, res) {
        return wrapThirdResponse(
            req,
            res,
            {
                order_id: 'String',
                source: 'String',
                atime: 'Number | String',
                sign: 'String'
            },
            data => {
                return OrderModel.updateOne({ order_id: data.orderId }, { $set: { is_written_off: 1 } }).then(() => {});
            }
        );
    }
    /**
     *
     * @param {Request} req
     * @param {Response} res
     */
    postOrderRefund(req, res) {
        return wrapThirdResponse(
            req,
            res,
            {
                order_id: 'String',
                refund_type: 'Number | String',
                source: 'String',
                atime: 'Number | String',
                sign: 'String'
            },
            data => {
                return OrderModel.updateOne({ order_id: data.orderId }, { $set: { refund_type: data.refundType } })
                    .then(() =>
                        SickQuestionModel.updateMany(
                            { orderId: data.orderId },
                            { $set: { refundStatus: data.refundType } }
                        )
                    )
                    .then(() => {});
            }
        );
    }
    /**
     * 账户打通
     * @param {Request} req
     * @param {Response} res
     */
    getAccount(req, res) {
        Promise.resolve()
            .then(() => getUser(req))
            .then(user => {
                res.status(200).send({
                    code: ResponseCode.SUCCESS,
                    content: {
                        url: outApi.createLoginUrl(user._id)
                    }
                });
            });
    }
}

module.exports = new Sick();
