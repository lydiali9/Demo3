let $url = require('../../utils/urls');
let $logger = require('../../utils/logger');
let $code = require('../../utils/code');
let $constant = require('../../utils/constant');
let $utils = require('../../utils/utils')
let OrderModel = require('../../models/medical/order');
let request_promise = require('request-promise');
let convert = require('xml-js');

function createOrder(fields) {
    return new Promise(function (resolve, reject) {
        OrderModel.create(fields, function (err, doc) {
            if (err) {
                $logger.error('method: createOrder, msg: 创建订单失败，' + err + " time:" + new Date());
                reject(err);
            } else {
                $logger.info('method: createOrder, msg: 创建订单成功；' + " time:" + new Date());
                resolve(doc);
            }
        });
    });
}

function updateOrder(order_id, status) {
    return new Promise(function (resolve, reject) {
        OrderModel.findOne({ order_id }, function (err, data) {
            if (err || data == null) {
                return reject(err);
            }
            OrderModel.update({ "order_id": order_id }, { status }, function (error, order) {
                if (error) {
                    $logger.error('method: updateOrder, msg: 修改订单失败，' + error + " time:" + new Date() + "order_id:" + order_id);
                    return reject(error);
                } else {
                    $logger.info('method: updateOrder, msg: 修改订单成功' + "order_id:" + order_id);
                    return resolve(order);
                }
            });
        })
    })
}
module.exports = {
    getOrderStatus: function (request, response) {
        let { orderId } = request.query;
        if (orderId == null) {
            $logger.error('method: getOrder, msg: 请求信息不完整');
            return response.json({ code: $code.QUERY_MYSQL_FALSE, msg: "请求信息不完整", content: {} });
        }
        OrderModel.findOne({ order_id: orderId }, function (err, data) {
            //0 支付失败 1支付成功
            if (err || data == null || data.status != 1) {
                let params = {
                    appid: $constant.APP_ID,
                    mch_id: $constant.MCH_ID,
                    out_trade_no: orderId,
                    nonce_str: $utils.uuid(32)
                };
                params.sign = $utils.getWeChatSign(params);
                $logger.log('调用微信支付订单查询接口，参数：' + params);

                let xmlStr = convert.js2xml({ xml: params }, { compact: true, ignoreComment: true, spaces: 4 });
                let options = {
                    method: "post",
                    uri: $url.wechat_order_query,
                    body: xmlStr,
                };
                request_promise(options).then(res => {
                    let result = convert.xml2js(res, { compact: true, spaces: 4 }).xml;
                    if (result.return_code._cdata === "SUCCESS"
                        && result.result_code._cdata === "SUCCESS"
                        && result.trade_state._cdata === "SUCCESS") {
                        //修改订单状态
                        updateOrder(orderId, $constant.PAY_COMPLETE);
                        return response.json({ code: $code.SUCCESS, msg: "success", content: { status: $constant.PAY_COMPLETE } });
                    } else {
                        return response.json({ code: $code.FALSE, msg: "fail", content: { status: $constant.NOT_PAY } });
                    }
                }).catch(e => {
                    return response.json({ code: $code.FALSE, msg: "fail", content: { status: $constant.NOT_PAY } });
                })
            } else {
                return response.json({ code: $code.SUCCESS, msg: "success", content: { status: $constant.PAY_COMPLETE } });
            }
        })
    },

    wxPay(request, response) {
        let { payType, feeType, money, uid } = request.body;
        if ($utils.isEmpty(payType) || $utils.isEmpty(feeType)
            || $utils.isEmpty(money) || $utils.isEmpty(uid)) {
            $logger.error('method: wechatPay, msg: 请求信息不完整');
            return response.json({ code: $code.QUERY_MYSQL_FALSE, msg: '请求信息不完整', content: {} })
        }
        //金额单位：分
        let total_fee = Number(money) * 100;
        //微信支付方式：APP、MWEB
        if (!["APP", "MWEB"].includes(payType) || (total_fee !== total_fee)) {
            $logger.error('method: wechatPay, msg: 支付方式或支付金额错误');
            return response.json({ code: $code.FALSE, msg: 'fail', content: {} })
        }


        let out_trade_no = `${$utils.uuid(8)}_${$utils.formatDate(new Date(), "yyyyMMddhhmmss")}`;
        let params = {
            appid: $constant.APP_ID,
            mch_id: $constant.MCH_ID,
            nonce_str: $utils.uuid(32),
            //TOFIX
            spbill_create_ip: $utils.getClientIp(request) && '218.17.116.242',
            notify_url: $url.wxpaynotify_url,
            //feeType 1：问诊费 2：感谢费
            body: `${feeType == 1 ? '问诊费' : '感谢费'}-${total_fee / 100}元`,
            out_trade_no: out_trade_no,
            total_fee: total_fee,
            trade_type: payType
        };

        params.sign = $utils.getWeChatSign(params)
        $logger.log('调用微信支付接口，参数：' + params);
        let xmlStr = convert.js2xml({ xml: params }, { compact: true, ignoreComment: true, spaces: 4 });
        let options = {
            method: "post",
            uri: $url.wechat_pay,
            body: xmlStr,
        };
        createOrder({ order_id: out_trade_no, money: total_fee, status: $constant.NOT_PAY, pay_type: payType, fee_type: feeType, uid }).then(result => {
            request_promise(options).then(res => {
                try {
                    let result = convert.xml2js(res, { compact: true, spaces: 4 }).xml
                    if (result.return_code._cdata === "SUCCESS" && result.result_code._cdata === "SUCCESS") {
                        const time_stamp = Math.floor(+new Date() / 1000);
                        const uuid = $utils.uuid(32);
                        if (payType == "APP") {
                            response.json({
                                code: $code.SUCCESS,
                                msg: 'success',
                                content: {
                                    prepayId: result.prepay_id._cdata,
                                    orderId: out_trade_no,
                                    extra: {
                                        app_id: $constant.APP_ID,
                                        partner_id: $constant.MCH_ID,
                                        package_value: $constant.PACKAGE,
                                        nonce_str: uuid,
                                        time_stamp: time_stamp,
                                        order_sign: $utils.getWeChatSign({
                                            prepayid: result.prepay_id._cdata,
                                            appid: $constant.APP_ID,
                                            partnerid: $constant.MCH_ID,
                                            package: $constant.PACKAGE,
                                            noncestr: uuid,
                                            timestamp: time_stamp,
                                        })
                                    }
                                }
                            })
                        } else if (payType == "MWEB") {
                            response.json({
                                code: $code.SUCCESS,
                                msg: 'success',
                                content: {
                                    prepayId: result.prepay_id._cdata,
                                    orderId: out_trade_no,
                                    extra: {
                                        mweb_url: result.mweb_url._cdata,
                                    }
                                }
                            })
                        }
                    } else {
                        $logger.error('调用微信支付统一下单接口失败');
                        response.json({ code: $code.FALSE, msg: 'fail', content: {} })
                    }
                } catch (e) {
                    $logger.error('处理微信支付统一下单数据发生异常：' + e);
                    response.json({ code: $code.FALSE, msg: 'fail', content: {} })
                }
            }).catch(err => {
                $logger.error('调用微信支付统一下单接口发生异常：' + err);
                response.json({ code: $code.FALSE, msg: 'fail', content: {} })
            })
        }).catch(e => {
            response.json({ code: $code.FALSE, msg: 'fail', content: {} })
        })
    },
    wxpayNotify(req, res) {
        let reqData = [];
        req.on('data', function (data) {
            reqData.push(data);
        });
        req.on('end', function () {
            let result = convert.xml2js(reqData.toString(), { compact: true, spaces: 4 }).xml;
            console.log(result)
            if (result.return_code._cdata === "SUCCESS" && result.result_code._cdata === "SUCCESS") {
                updateOrder(result.out_trade_no._cdata, $constant.PAY_COMPLETE);
            }
            res.send(` <?xml version="1.0" encoding="UTF-8" standalone="no"?><xml><return_code>SUCCESS</return_code><return_msg>OK</return_msg> </xml>`)
        });
    }
}